import tkinter as tk
from random import randint
import numpy as np

root = tk.Tk()


canvas = tk.Canvas(root, background="grey", width=416, height=468)
canvas.pack()

island = tk.PhotoImage(file="ostrov0.png")
bridge_horizontal = tk.PhotoImage(file="ostrov1.png")
bridge_vertical = tk.PhotoImage(file="ostrov2.png")
empty = tk.PhotoImage(file="ostrov3.png")
currency = tk.PhotoImage(file="ostrov_kruh0.png")

SIDE = empty.width()

islands = []
bridges_h = []
bridges_v = []
empties = []
coin = 0
label = 0


root.geometry("416x468")


def click(e):
    global empties, bridges_h, bridges_v, label
    for overlap in canvas.find_overlapping(e.x, e.y, e.x, e.y):
        coords = canvas.coords(overlap)
        if overlap in empties:
            empties.remove(overlap)
            bridges_v.append(overlap)
            canvas.itemconfig(overlap, image=bridge_vertical)

        elif overlap in bridges_v:
            bridges_v.remove(overlap)
            bridges_h.append(overlap)
            canvas.itemconfig(overlap, image=bridge_horizontal)

        elif overlap in bridges_h:
            bridges_h.remove(overlap)
            empties.append(overlap)
            canvas.itemconfig(overlap, image=empty)


def setup():
    global islands, empties

    m = randint(4, 6)
    n = randint(3, 9)

    for i in range(m):
        for j in range(n):
            rng = randint(0, 4)
            if rng == 0:
                islands.append(canvas.create_image(3 + i*(SIDE+1), 3+j*(SIDE+1), anchor="nw", image=island))
            else:
                empties.append(canvas.create_image(3 + i*(SIDE+1), 3+j*(SIDE+1), anchor="nw", image=empty))
    coin = canvas.create_image(10 + 7*SIDE, 3, image=currency)
    label = canvas.create_text(10 + 7*SIDE, 4 + SIDE, text="15")



canvas.bind("<1>", click)

canvas.after(100, setup)
root.mainloop()
